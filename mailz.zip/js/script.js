function show_message() {
	$("#message_box").animate({
		top: "0px",
		opacity: 1
	}, "slow"),
	setTimeout("hide_message()", 2e3);
}
function hide_message() {
	$("#message_box").animate({
		top: "-30px",
		opacity: 0
	}, "slow");
}

function kontrol() {
    $.post("inc/list.php", {_: new Date().getTime()}, function() {}).done(function(t) {
        seconds.setText(":)"), $(".bilgi").html("done"), clearInterval(sayac), saniye = 10, sayac(), $("#epostalar").html(t)
    }).fail(function() {
        seconds.setText(":("), $(".bilgi").html("An error occurred")
    }).always(function() {})
}

function sayac() {
    var t = setInterval(function() {
        0 == saniye && (seconds.setText("0"), $(".bilgi").html("updating...")), 0 > saniye && (seconds.stop(), clearInterval(t), kontrol(), saniye = 0), 9 == saniye && $(".bilgi").html("next update in");
        var a = saniye;
        seconds.animate(1 - a / 10, function() {
            0 != a && seconds.setText(a)
        }), saniye -= 1
    }, 1e3)
	var counter = $('#mail_list').attr('data-counter');
	if(counter > 0)	document.title = '('+counter+') MailZ - Disposable Temporary Email';
}

var element = $(".geri-say")[0],
    saniye = 9,
    seconds = new ProgressBar.Circle(element, {
        duration: 0,
        color: "#999",
        trailColor: "#eee",
        strokeWidth: 5,
        text: {
            value: "10"
        }
    });

	
var clipboard = new Clipboard(".kopyala-buton");
clipboard.on("success", function (t) {
	show_message()
});

$(document).ready(function() {

	sayac();


	$('#ajax').load("inc/list.php?old", {_: new Date().getTime()},function() {
		var counter = $('#mail_list').attr('data-counter');
		if(counter > 0)	document.title = '('+counter+') MailZ - Disposable Temporary Email';
	});

    

	$('#ajax').delegate('.view_msg', 'click', function(event) {
		var $msgID = $(this).attr('data-message-id');
		$('#ajax').load("inc/view.php", {_: new Date().getTime(), id: $msgID},function() {
			var counter = $('#mail_list').attr('data-counter');
			if(counter > 0)	document.title = '('+counter+') MailZ - Disposable Temporary Email';
		});
	});

	$('#ajax').delegate('#back_btn', 'click', function(event) {
		$('#ajax').load("inc/list.php", {_: new Date().getTime()},function() {
			var counter = $('#mail_list').attr('data-counter');
			if(counter > 0)	document.title = '('+counter+') MailZ - Disposable Temporary Email';
		});
	});



	$('#ajax').delegate('#delete_btn', 'click', function(event) {
		var $target = $(this).attr('data-target');
		$('#ajax').load("inc/list.php?del="+$target, {_: new Date().getTime()},function() {
			var counter = $('#mail_list').attr('data-counter');
			if(counter > 0)	document.title = '('+counter+') MailZ - Disposable Temporary Email';
		});
	});

	

	$("#eposta_adres").click(function () {
		$(this).select()
	});


});