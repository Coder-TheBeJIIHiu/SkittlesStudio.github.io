<?php
@session_name('MailZ');
@session_start();

if ((isset($_COOKIE['email']) && $_COOKIE['email'] != '')) {
	$_SESSION['email'] = base64_decode($_COOKIE['email']);
}else{
	include 'inc/create.php';
}

$ThisEmail = $_SESSION['email'];

?>
<!doctype html>
<html class="no-js" lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="x-ua-compatible" content="ie=edge,chrome=1">
		<title>MailZ - Disposable Temporary Email</title>
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/style.min.css"> 
		<link rel="icon" href="favicon.png" type="image/png"/>
		<link rel="shortcut icon" href="favicon.png" type="image/png"/>
	</head>
<body>
<header>
    <div class="ust-cerceve">
      <div class="logo">
        <a href="/" title="MailZ create a disposable email address. You can use it for sign up to any websites, and you can read incoming emails.">
          <img src="images/logo.png" alt="MailZ: Disposable Temporary Email">
        </a>
      </div>
      <div class="geri-say" style="position: relative;">
        <div class="bilgi desk">updating...</div>
        <div class="ok desk"></div>
		</div>
	</div>
  </header>
  <div class="icerik">
    <div id="orta" class="orta">
      <div class="adres-alani">
        <div class="adres">
          <input id="eposta_adres" type="text" class="adres-input" value="<?=$ThisEmail?>" data-value="<?=$ThisEmail?>" readonly="">
          <i class="fa fa-envelope"></i>
        </div>
        <button type="button" class="button button-action kopyala-buton mobi" data-clipboard-target="#eposta_adres"><i class="fa fa-clone"></i> Copy</button>
        <button type="button" class="button button-action kopyala-buton desk" data-clipboard-target="#eposta_adres"><i class="fa fa-clone"></i> Copy</button>
      </div>

      <div id="ajax"></div>
      <div class="hakkinda kutu mavi desk">
        <div class="kutu-ici">
          MailZ.info provides temporary, anonymous, free, secure, disposable email address. You can use on facebook, twitter or instagram for anonymously sign up!</div>
      </div>
    </div>
  </div>
  <footer>
    <div class="copyright">
      © <?php echo date("Y"); ?>  <a href="https://mailz.info" title="Disposable Temporary Email">MailZ.info</a>
    </div>
  </footer>
  <div id="message_box">Coppied : <strong><?=$ThisEmail?></strong></div>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="js/clipboard.min.js"></script>
<script type="text/javascript" src="js/progressbar.min.js"></script>
<script type="text/javascript" src="js/script.min.js"></script>
</body></html>