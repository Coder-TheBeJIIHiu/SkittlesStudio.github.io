<?php
@session_name('MailZ');
@session_start();
include_once("functions.php");

$pdo = new PDO("sqlite:MailZDB.db");

if (isset($_GET['del'])) {
	$del = $_GET['del'];
	$pdo->query("DELETE FROM `emails` WHERE `id`='$del'");
}


if (isset($_GET['old'])) { 
    if ((isset($_COOKIE['email']) && $_COOKIE['email'] != '')) {
    	$_SESSION['email'] = base64_decode($_COOKIE['email']);
	}else{
		 include 'create.php';
	}
}

$ThisEmail = $_SESSION['email'];

if ($ThisEmail == "") {
	include 'create.php';
}



$count  = $pdo->query("SELECT count(id) FROM `emails`");
if($count > 0){
	$counter = $pdo->query("SELECT count(id) FROM `emails` WHERE `to` LIKE '%$ThisEmail%'")->fetchColumn();
	$emails = $pdo->query("SELECT * FROM `emails` WHERE `to` LIKE '%$ThisEmail%'")->fetchAll(PDO::FETCH_ASSOC);
}else{
	$emails = 0;
	$counter = 0;
}

?>
<section class="tam-konteyner gri-bg" style="padding-top:0">
  <div class="ana-konteyner">
    <div class="mail-alani">
      <div id="epostalar">
		<ul class="mailler" id="mail_list" data-counter="<?=$counter?>" data-email="<?=$ThisEmail?>">
		  <li class="baslik">
			<div class="gonderen">Sender</div>
			<div class="baslik">Subject</div>
			<div class="zaman">Time</div>
		  </li>
		  <?if($emails){
			  foreach ($emails as $k => $m) { ?>
			  <li class="mail">
				<a class="view_msg" data-message-id="<?=$m['id']?>">
				  <div class="avatar"><img src="images/posta.png"></div>
				  <div class="gonderen"><?=htmlentities($m['from'])?></div>
				  <div class="baslik"><?=htmlentities($m['subject'])?></div>
				  <div class="zaman"><?=time_elapsed_string(htmlentities($m['date']))?></div>
				</a>
			  </li>
		<? }
		  }else{		?>
		  <li>
			<div class="eposta-bekleniyor">
			  <p class="yukleniyor">Waiting for emails<span>.</span><span>.</span><span>.</span></p>
			  <div><img src="images/empty.png" alt="temp mail"></div>
			</div>
		  </li>
		  <? } ?>
		</ul>
      </div>
    </div>
  </div>
</section>