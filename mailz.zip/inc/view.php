<?php
$id = intval($_POST['id']);
$pdo = new PDO("sqlite:MailZDB.db");
$email = $pdo->query("SELECT * FROM `emails` WHERE `id`='$id'")->fetch(PDO::FETCH_ASSOC);

$email_body = base64_decode($email['message']);

$letter_html = "";
$op_getKey = preg_match_all("/boundary=\"(.*)\"/", $email_body, $getKey);
$has_attachment = preg_match_all("/multipart\/mixed/", $email_body, $attachment);
if ($op_getKey) {
	if ($has_attachment) {
		$mailParts = explode("--" . $getKey[1][1], $email_body);
		$attachParts = explode("--" . $getKey[1][0], $email_body);
	
		$get_attach_name=preg_match_all("/filename=\"(.*?)\"/", $attachParts[2], $attach_name);
		$get_attach_type=preg_match_all("/Content-Type: (.*?);/", $attachParts[2], $attach_type);
		$pure_code = explode("\n\n",$attachParts[2]);
		$pure_code = str_replace("\r","",$pure_code[1]);
		$pure_code = str_replace("\n","",$pure_code);
	}else{
		$mailParts = explode("--" . $getKey[1][0], $email_body);
	}


	$the_mail = $mailParts[2];


	$to_replace = array(
		'Content-Type: text/html; charset="UTF-8"',
		'Content-Type: text/html; charset=UTF-8',
		'Content-Type: text/html; charset="utf-8"',
		'Content-Type: text/html; charset=utf-8',
		'Content-Type: text/html; charset="iso-8859-1"',
		'Content-Type: text/html; charset=iso-8859-1',
		'Content-Type: text/html; charset="ISO-8859-1"',
		'Content-Type: text/html; charset=ISO-8859-1',
		'Content-Type: text/plain; charset="iso-8859-1"',
	);

	foreach ($to_replace as $k => $v) {
		$the_mail = str_replace($to_replace[$k], '', $the_mail);
	}
	


	if (preg_match_all("/Content-Transfer-Encoding: quoted-printable/", $the_mail, $mailToDecode)) {
		$message_to_decode = str_replace('Content-Transfer-Encoding: quoted-printable', '', $the_mail);
		$letter_html = quoted_printable_decode($message_to_decode);
	}elseif(preg_match_all("/Content-Transfer-Encoding: base64/", $the_mail, $mailToDecode)){
		$message_to_decode = str_replace('\r', '', $the_mail);
		$message_to_decode = str_replace('\n', '', $message_to_decode);
		$message_to_decode = str_replace('Content-Transfer-Encoding: base64', '', $message_to_decode);
		$letter_html = base64_decode($message_to_decode);
	} else {
		$letter_html = $the_mail;
	}

} else {


	$mailParts = explode("\n\n", $email_body);



	foreach ($mailParts as $k => $v) {
		if ($k > 0) {
			$letter_html .= $v . "\n\n";
		}
	}

	if(preg_match_all("/Content-Transfer-Encoding: base64/", $email_body, $mailToDecode)){
		$message_to_decode = str_replace('\r', '', $letter_html);
		$message_to_decode = str_replace('\n', '', $message_to_decode);
		$letter_html = base64_decode($message_to_decode);
		
	}


	
}
?>

  <div class="mail-oku">
    <div class="mail-oku-menu">
      <a id="back_btn" class="tus tus-kucuk yasla-sol"><i class="fa fa-arrow-left"></i><span class="desk"> Back</span></a>
      <button id="delete_btn" data-target="<?=$id?>" class="tus tus-kucuk "><i class="fa fa-times"></i><span class="desk"> Delete</span></button>
    </div>
    <div class="mail-oku-gonderen">
      <p>From: <b><?=htmlentities($email['from'])?></b></p>
      <p>Date: <b><?=htmlentities($email['date'])?></b></p>
      <p>Subject: <b><?=htmlentities($email['subject'])?></b></p>
    <hr>
	<?php if ($has_attachment) { ?>
		<div id="attach_info">Attachment: <a target="_blank" href="data:<?=$attach_type[1][0]?>;base64,<?=$pure_code?>"><?=$attach_name[1][0]?></a></div>
		
	<?php } ?>
    <div id="view_body" class="mail-oku-panel">
	<?=$letter_html?>
    </div>
	</div>
  </div>
