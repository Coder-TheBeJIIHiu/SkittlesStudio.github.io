#!/usr/bin/php -q
<?php
$fd = fopen("php://stdin", "r");
$email = "";
while (!feof($fd)) {
    $email .= fread($fd, 1024);
}
fclose($fd);



$op_getReceiver = preg_match_all("/To: (.*)/", $email, $getReceiver);
$_Receiver = $getReceiver[1][0];
//$_Receiver = end($getReceiver[1]); // recived forwarded mail

$op_getSender = preg_match_all("/From: (.*)\n/", $email, $getSender);
$_Sender = $getSender[1][0];

$op_getDate = preg_match_all("/Date: (.*)/", $email, $getDate);
$_Date = $getDate[1][0];

$op_getSubject = preg_match_all("/Subject: (.*)\n/", $email, $getSubject);
$_Subject = $getSubject[1][0];


$pdo = new PDO("sqlite:inc/MailZDB.db");
$_Email = base64_encode($email);
if (strpos($_Subject, '=?UTF-8?B?') !== false) {
$_Subject = base64_decode(substr($_Subject,10,-2));
}
$execute=$pdo->query("INSERT INTO `emails` VALUES (NULL,'$_Receiver','$_Sender','$_Subject','$_Date','$_Email')");
if (!$execute) {
	$handler=fopen('error.txt','a');
	fwrite($handler,$_Email."\n\n\n-------------------------------------------\n\n\n");
	fclose($handler);
}


?>